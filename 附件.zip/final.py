from hashlib import md5
from base64 import b64decode, b64encode
import struct, math, random, functools, lief
from Crypto.PublicKey import RSA

# parsing consts
so = lief.parse('./lib52pojie.so')
content = bytes(so.get_section('.data').content[8:][:4+4+128+128])
n = int.from_bytes(content[8:][:128], 'big')
assert n == 0xbfbdcc68db43621b3d16e308b8cbb66ad6715da8e46b76f1731bcfa26107ff3012fc585565b3efe01d83d30198078a34f80bade1fb5d23c6ccff8026e6d187de723bdfd1f263d700ca8c664919a885783c40f0eb2fc6282233c14b9efe8f0f995623cd6095d266d3edba0520a34d99e07b3412afc7bde7f26c9b937252786d87
d1 = int.from_bytes(content[8+128:], 'big')
assert d1 == 0x3c9bf2cf5f948d635c8be9a69293a75fef179dce9dea355ad7b18158f89b5105e864aeb58088a3f529a1e0c1faf0c7a3b02809d38c160d8d4d4490bec3b5b30200a7afb8f8aa523cfc00cfa2ec35880b688e7fe983f0c3688885ebd0fb27a19c7ac039df7eda59d538d5a479e8ce45658a177a2164c032940644bc1e7fb3961e
# logic to calc d2
d2_bytes = b''
start_to_hash, size_to_hash = struct.unpack('<II', content[:8])
so_hash = md5(md5(bytes(so.get_content_from_virtual_address(start_to_hash, size_to_hash))).digest()).digest()
assert so_hash.hex() == '54c6fed759984e8d27bff5d9e6489235'
d2_bytes += so_hash
# python impl of genuine(or old KernelSU)'s v2 sign
def get_v2_signature(path, verbose=False, dump_cert=False):
    buf = open(path, 'rb').read()
    off = 0
    i = 0
    # find zip's EOCD
    while True:
        off = len(buf) - i - 2
        n, = struct.unpack('<H', buf[off:off+2])
        if n == i:
            off -= 20
            if (struct.unpack('<I', buf[off:off+4])[0] ^ 0xcafebabe) == 0xccfbf1ee:
                break
        assert i < 0xffff, 'cannot find eocd'
        i += 1
    off += 16
    offset, = struct.unpack('<I', buf[off:off+4])
    off = offset - 0x18
    # apk sig block is before the central directory starts
    sig_block_size, = struct.unpack('<Q', buf[off:off+8])
    off += 8
    assert buf[off:off+0x10] == b'APK Sig Block 42', 'sig block magic mismatch'
    off = offset - sig_block_size
    assert struct.unpack('<Q', buf[off-8:off])[0] == sig_block_size, 'sig block size mismatch'
    first_hash = None
    cert_cnt = 0
    while True:
        cur_size, id_value = struct.unpack('<QI', buf[off:off+12])
        if cur_size == sig_block_size:
            break
        if verbose:
            print(f'offset: 0x{off:08x}, size: 0x{cur_size:08x}, id: 0x{id_value:08x}')
        cur_off = off + 8
        off += 12
        if (id_value ^ 0xdeadbeef) == 0xafa439f5 or (id_value ^ 0xdeadbeef) == 0x2efed62f:
            off += 4 * 3 # signer-sequence length, signer length, signed data length
            off += 4 + struct.unpack('<I', buf[off:off+4])[0] # digests-sequence length, digests-sequence
            off += 4 # certificates length
            cert_size, = struct.unpack('<I', buf[off:off+4]) # certificate length
            off += 4
            cert = buf[off:off+cert_size]
            base_hash = 1
            if dump_cert:
                cert_cnt += 1
                open(f'cert_{cert_cnt}.crt', 'wb').write(cert)
            for i, v in enumerate(cert):
                base_hash = (base_hash * 31 + (v if v < 0x80 else v - 256 + 2**32)) & 0xffffffff
            base_hash ^= 0x14131211
            if not verbose:
                return base_hash
            print(f"    size: 0x{cert_size:04x}, hash: 0x{base_hash:08x}")
            if first_hash is None:
                first_hash = base_hash
        off = cur_off + cur_size
    return first_hash
    
sig_hash = get_v2_signature('./【2024春节】解题领红包之Android高级题.apk')
assert sig_hash == 0xccf1c7a4
cur = md5(struct.pack('<I', sig_hash)).digest()
d2_bytes += cur
for i in range(6):
    cur = md5(cur).digest()
    d2_bytes += cur

d2_bytes = b'\x00\x00' + d2_bytes[2:] # clear first word
d2 = int.from_bytes(d2_bytes, 'big')
assert d2 == 0x0000fed759984e8d27bff5d9e6489235766208198dbc9d32fbabd176dc246d27bef6968b7b536431ff0bf00616c9581b4b28621a8b302954c2462a969c9b7c1739b397b030fe0b959dc94135776c6d046504e934679c11051e0b25e95796ebec029ae39affcccf09c738e07f286a2171e435415ab021f5810b4b1fca817584d3
d = d1 + d2

def verify_logic(uid, data):
    sn = str(uid).zfill(8)
    sn_hash = md5(sn.encode()).digest() # in java
    data = b64decode(data) # in checkSn
    # start of decryptInternal
    # check !(__system_property_get("init.svc.adbd", str) && strncmp(str, "running", 7))
    # BigNumber::init n(...a0), d1(...80), d2(...60, from parsing logic), c(...40, from base64decoded data)
    c = int.from_bytes(data, 'big')
    bn20 = pow(c, d1, n)
    bn00 = pow(c, d2, n)
    bne0 = bn20 * bn00
    # ...c0
    m = bne0 % n
    assert m == pow(c, d1 + d2, n)
    # check !ACameraManager_getCameraIdList(ACameraManager_create(), &list) && list->numCameras == 2
    m_bytes = m.to_bytes(128, 'big')
    # here we do signature verification actually, but BT=2 and e/d is reversed
    # but it cannot be breakable since e'(d1+d2) is not too small
    if m_bytes[:2] != b'\x00\x02':
        return False
    idx = m_bytes[2:].find(0)
    if idx < 8: # including -1
        return False
    decrypted = m_bytes[2+idx+1:]
    # end of decryptInternal
    ans = [0] * len(decrypted)
    # in checkSn
    for i, v in enumerate(decrypted):
        v14 = (((32 * (v + i)) ^ (((v + i) & 0xff) >> 3)) - i) ^ 0x69
        v14 &= 0xff
        v15 = ((((32 * v14) ^ (v14 >> 3) ^ 5) - 14) ^ i) + i
        v15 &= 0xff
        ans[i] = (-((((((0xff & (((8 * v15) ^ (v15 >> 5)) + i)) >> 5) | (8 * (((8 * v15) ^ (v15 >> 5)) + i))) ^ 0xC8) + i) & 0xff)) & 0xff
    return bytes(ans)[:16] == sn_hash # note: here, ans longer than 16 is also ok

def bytewise_decrypt(ans):
    inp = [0] * len(ans)
    for i, ans_v in enumerate(ans):
        correct = None
        for v in range(256):
            v14 = (((32 * (v + i)) ^ (((v + i) & 0xff) >> 3)) - i) ^ 0x69
            v14 &= 0xff
            v15 = ((((32 * v14) ^ (v14 >> 3) ^ 5) - 14) ^ i) + i
            v15 &= 0xff
            w = (-((((((0xff & (((8 * v15) ^ (v15 >> 5)) + i)) >> 5) | (8 * (((8 * v15) ^ (v15 >> 5)) + i))) ^ 0xC8) + i) & 0xff)) & 0xff
            if w == ans_v:
                assert correct is None
                correct = v
        assert correct is not None
        inp[i] = correct
    return bytes(inp)

# if we know e(in fact is d) is small and e*d = klambda(n)+1, and gcd(p-1,q-1) == 2, then we can get e by coppersmith
def get_e():
    from sage.all import Sequence, vector, QQ, ZZ, prod, power, Zmod
    import itertools
    def small_roots(f, bounds, m=1, d=None):
        if not d:
            d = f.degree()
        R = f.base_ring()
        N = R.cardinality()
        f /= f.coefficients().pop(0)
        f = f.change_ring(ZZ)
        G = Sequence([], f.parent())
        for i in range(m+1):
            base = N**(m-i) * f**i
            for shifts in itertools.product(range(d), repeat=f.nvariables()):
                g = base * prod(map(power, f.variables(), shifts))
                G.append(g)
        B, monomials = G.coefficient_matrix()
        monomials = vector(monomials)
        factors = [monomial(*bounds) for monomial in monomials]
        for i, factor in enumerate(factors):
            B.rescale_col(i, factor)
        B = B.dense_matrix().LLL()
        B = B.change_ring(QQ)
        for i, factor in enumerate(factors):
            B.rescale_col(i, 1/factor)
        H = Sequence([], f.parent().change_ring(QQ))
        for h in filter(None, B*monomials):
            H.append(h)
            I = H.ideal()
            if I.dimension() == -1:
                H.pop()
            elif I.dimension() == 0:
                roots = []
                for root in I.variety(ring=ZZ):
                    root = tuple(R(root[var]) for var in f.variables())
                    roots.append(root)
                return roots
        return []
    R = Zmod(d)
    P = R['k,s']; k, s = P.gens()
    f = k*((n+1)//2 - s) + 1
    k, s = small_roots(f, (2**48, 2**512), m=3, d=4)[0]
    e = (int(k)*((n+1)//2 - int(s)) + 1) // d
    return e

e = 0x200001 # in hint
# assert get_e() == e
# useless in hint. in fact, it's not the \phi(n), but the \lambda(n)
phi = 0x5FDEE6346DA1B10D9E8B71845C65DB356B38AED47235BB78B98DE7D13083FF98097E2C2AB2D9F7F00EC1E980CC03C51A7C05D6F0FDAE91E3667FC0137368C3EE5B6E262BF566AAADAD8F5755F4C654805D9D82C075A9334B10EEF11D40681B8C3DD44E781D1FA393F50B106889E1870C30D49411FDA6B7C41DA38F16F0980AD0
rsa = RSA.construct((n, e, d))
assert rsa.p == 0xd5fe6200735bf42e8a04d625374ac00ee43a7900ce901e0f97acd81bfbbb430945963d1ce25a8e368553371ec0f2d269d3ec2735483a2561cd75d6010327a371
assert rsa.q == 0xe5613179943a8d76e568e177f8d11c689ccb726975e3a37c7a3691488203957794e4f353793891757e50ad30ce97b95e459ec3568436530863de9f436e20b477
# polyfill for low version of python
try:
    math.lcm
except AttributeError:
    math.lcm = lambda *args: functools.reduce(lambda p, q: p*q//math.gcd(p, q) if p*q else 0, args)
assert phi == math.lcm(rsa.p - 1, rsa.q - 1)
assert pow(d, -1, phi) == e
# note is not easy to cover n from phi here since phi is not easy to be fully factored here

def rsa_pkcsv15(content):
    packed = b'\x00\x02' + bytes([random.randrange(1, 256) for _ in range(128 - 2 - 1 - len(content))]) + b'\x00' + content
    return pow(int.from_bytes(packed, 'big'), e, n).to_bytes(128, 'big')

def calc_ans_for_uid(uid):
    sn = str(uid).zfill(8)
    sn_hash = md5(sn.encode()).digest()
    return b64encode(rsa_pkcsv15(bytewise_decrypt(sn_hash))).decode()

uid = 691872
ans = calc_ans_for_uid(uid)
print('Before test on Android, run setprop init.svc.adbd stopped')
print('ans:', ans)
assert verify_logic(uid, ans)
# more hint after solved
assert verify_logic(1, 'fDTeZC/LTjSMhF2l4BX5lkeXTwdAJyGVTpnHukjSx+oqjQUxPYSyYQDqMjrS6GLxQtd2PZB2bU4sjmZKOIAn4xWv6lcbEDYfF75NV6TaFFB5S0E4kT5Png14cQtF0sSe55dEmPr4W0umsCJf2rkla0GAhIhPvlcLHqzU4Knxee4=')
