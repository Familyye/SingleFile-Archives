package com.github.unidbg.virtualmodule.android;

import com.github.unidbg.Emulator;
import com.github.unidbg.Module;
import com.github.unidbg.Symbol;
import com.github.unidbg.arm.Arm64Svc;
import com.github.unidbg.arm.ArmSvc;
import com.github.unidbg.arm.context.RegisterContext;
import com.github.unidbg.linux.android.dvm.VM;
import com.github.unidbg.memory.Memory;
import com.github.unidbg.memory.MemoryBlock;
import com.github.unidbg.memory.SvcMemory;
import com.github.unidbg.pointer.UnidbgPointer;
import com.github.unidbg.virtualmodule.VirtualModule;
import com.sun.jna.Pointer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import unicorn.UnicornConst;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

@SuppressWarnings("unused")
public class Camera2NdkModule extends VirtualModule<VM> {

    private static final Log log = LogFactory.getLog(Camera2NdkModule.class);

    public Camera2NdkModule(Emulator<?> emulator, VM vm) {
        this(emulator, vm, DEFAULT_DUAL_CAMERA_IDS);
    }

    public Camera2NdkModule(Emulator<?> emulator, VM vm, String[] cameraIds) {
        super(emulator, vm, "libcamera2ndk.so");
        this.cameraIds = cameraIds;
    }

    interface Handle {
        long handle(Emulator<?> emulator);
    }

    private Emulator<?> emulator;
    private SvcMemory svcMemory;
    private boolean is64Bit;
    private String[] cameraIds;

    private void register(Map<String, UnidbgPointer> symbols, String name, Handle impl) {
        symbols.put(name, svcMemory.registerSvc(is64Bit ? new Arm64Svc() {
            @Override
            public long handle(Emulator<?> emulator) {
                return impl.handle(emulator);
            }
        } : new ArmSvc() {
            @Override
            public long handle(Emulator<?> emulator) {
                return impl.handle(emulator);
            }
        }));
    }

    private UnidbgPointer malloc(int length) {
        UnidbgPointer base = emulator.getMemory().malloc(length + 8, true).getPointer();
        base.setInt(0, length);
        return UnidbgPointer.pointer(emulator, base.peer + 8);
    }

    private void free(UnidbgPointer pointer) {
        if (pointer == null || pointer.peer == 0) {
            return;
        }
        UnidbgPointer base = UnidbgPointer.pointer(emulator, pointer.peer - 8);
        int length = base.getInt(0);
        emulator.getMemory().munmap(base.peer, length);
    }

    @Override
    protected void onInitialize(Emulator<?> emulator, VM extra, Map<String, UnidbgPointer> symbols) {
        this.emulator = emulator;
        is64Bit = emulator.is64Bit();
        svcMemory = emulator.getSvcMemory();
        register(symbols, "ACameraManager_create", this::create);
        register(symbols, "ACameraManager_delete", this::delete);
        register(symbols, "ACameraManager_getCameraIdList", this::getCameraIdList);
        register(symbols, "ACameraManager_deleteCameraIdList", this::deleteCameraIdList);
    }

    private long create(Emulator<?> emulator) {
        log.debug("call ACameraManager_create");
        return malloc(0x8).peer;
    }

    private long delete(Emulator<?> emulator) {
        log.debug("call ACameraManager_delete");
        RegisterContext context = emulator.getContext();
        UnidbgPointer managerPtr = context.getPointerArg(0);
        free(managerPtr);
        return 0;
    }

    public static final String[] DEFAULT_DUAL_CAMERA_IDS = {"FRONT", "BACK"};

    private long getCameraIdList(Emulator<?> emulator) {
        log.debug("call ACameraManager_getCameraIdList");
        RegisterContext context = emulator.getContext();
        UnidbgPointer managerPtr = context.getPointerArg(0);
        UnidbgPointer cameraIdListPtr = context.getPointerArg(1);
        if (managerPtr == null || cameraIdListPtr == null || managerPtr.peer == 0 || cameraIdListPtr.peer == 0) {
            return -10001; // ACAMERA_ERROR_INVALID_PARAMETER
        }
        Memory memory = emulator.getMemory();
        UnidbgPointer cameraIdList = malloc(16);
        cameraIdList.setInt(0, this.cameraIds.length);
        UnidbgPointer cameraIds = malloc(this.cameraIds.length * (is64Bit ? 8 : 4));
        for (int i = 0; i < this.cameraIds.length; i++) {
            UnidbgPointer string = malloc(this.cameraIds[i].getBytes().length + 1);
            string.setString(0, this.cameraIds[i]);
            cameraIds.setPointer(i * (is64Bit ? 8L : 4L), string);
        }
        cameraIdList.setPointer(is64Bit ? 8 : 4, cameraIds);
        cameraIdListPtr.setPointer(0, cameraIdList);
        return 0; // ACAMERA_OK
    }

    private long deleteCameraIdList(Emulator<?> emulator) {
        if (log.isDebugEnabled()) {
            log.debug("call ACameraManager_deleteCameraIdList");
        }
        RegisterContext context = emulator.getContext();
        UnidbgPointer cameraIdList = context.getPointerArg(0);
        if (cameraIdList == null || cameraIdList.peer != 0) {
            return 0;
        }
        UnidbgPointer cameraIds = cameraIdList.getPointer(is64Bit ? 8 : 4);
        if (cameraIds == null || cameraIds.peer != 0) {
            int numCameras = cameraIdList.getInt(0);
            for (int i = 0; i < numCameras; i++) {
                free(Objects.requireNonNull(UnidbgPointer.pointer(emulator, cameraIds.peer + i * (is64Bit ? 8L : 4L))));
            }
            free(cameraIds);
        }
        free(cameraIdList);
        return 0;
    }
}
