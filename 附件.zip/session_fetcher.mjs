export class SessionFetch {
    constructor(site) {
        this.cookies = new Map();
        this.site = site ? (site.endsWith('/') ? site.slice(0, -1) : site) : '';
    }
    toCookieString() {
        return [...this.cookies.entries()].map(([k, v]) => `${encodeURIComponent(k)}=${v}`).join('; ');
    }
    addCookie(name, value, encoded = false) {
        this.cookies.set(name, encoded ? value : encodeURIComponent(v));
    }
    async fetch(url, options) {
        if (url.startsWith('/') && this.site) {
            url = this.site + url;
        }
        if (!options) options = {}; else options = { ...options };
        if (options.headers) options.headers = { ...options.headers };
        if (options.headers && options.headers.cookie) {
            options.headers.cookie = options.headers.cookie.replaceAll('{session}', this.toCookieString().replaceAll('$', '$$$$'))
        } else if (this.cookies) {
            if (!options.headers) options.headers = {};
            options.headers.cookie = this.toCookieString();
        }
        return fetch(url, options).then(resp => {
            resp.headers.getSetCookie().forEach(v => {
                v = v.split(';')[0];
                let [name, ...value] = v.split('=');
                this.addCookie(decodeURIComponent(name), value.join('='), true);
            });
            return resp;
        });
    }
};
