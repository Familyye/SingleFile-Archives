function Grid(size, previousState) {
  this.size = size;
  this.cells = previousState ? this.fromState(previousState) : this.empty();
}

// Build a grid of the specified size
Grid.prototype.empty = function () {
  var cells = [];

  for (var x = 0; x < this.size; x++) {
    var row = cells[x] = [];

    for (var y = 0; y < this.size; y++) {
      row.push(null);
    }
  }

  return cells;
};

Grid.prototype.fromState = function (state) {
  var cells = [];

  for (var x = 0; x < this.size; x++) {
    var row = cells[x] = [];

    for (var y = 0; y < this.size; y++) {
      var tile = state[x][y];
      row.push(tile ? new Tile(tile.position, tile.value) : null);
    }
  }

  return cells;
};

// Find the first available random position
Grid.prototype.randomAvailableCell = function () {
  var cells = this.availableCells();

  if (cells.length) {
    return cells[Math.floor(Math.random() * cells.length)];
  }
};

Grid.prototype.availableCells = function () {
  var cells = [];

  this.eachCell(function (x, y, tile) {
    if (!tile) {
      cells.push({ x: x, y: y });
    }
  });

  return cells;
};

// Call callback for every cell
Grid.prototype.eachCell = function (callback) {
  for (var x = 0; x < this.size; x++) {
    for (var y = 0; y < this.size; y++) {
      callback(x, y, this.cells[x][y]);
    }
  }
};

// Check if there are any cells available
Grid.prototype.cellsAvailable = function () {
  return !!this.availableCells().length;
};

// Check if the specified cell is taken
Grid.prototype.cellAvailable = function (cell) {
  return !this.cellOccupied(cell);
};

Grid.prototype.cellOccupied = function (cell) {
  return !!this.cellContent(cell);
};

Grid.prototype.cellContent = function (cell) {
  if (this.withinBounds(cell)) {
    return this.cells[cell.x][cell.y];
  } else {
    return null;
  }
};

// Inserts a tile at its position
Grid.prototype.insertTile = function (tile) {
  this.cells[tile.x][tile.y] = tile;
};

Grid.prototype.removeTile = function (tile) {
  this.cells[tile.x][tile.y] = null;
};

Grid.prototype.withinBounds = function (position) {
  return position.x >= 0 && position.x < this.size &&
         position.y >= 0 && position.y < this.size;
};

Grid.prototype.serialize = function () {
  var cellState = [];

  for (var x = 0; x < this.size; x++) {
    var row = cellState[x] = [];

    for (var y = 0; y < this.size; y++) {
      row.push(this.cells[x][y] ? this.cells[x][y].serialize() : null);
    }
  }

  return {
    size: this.size,
    cells: cellState
  };
};

Grid.prototype.clone = function () {
  var s = this.serialize();
  return new Grid(s.size, s.cells);
};

function Tile(position, value) {
  this.x                = position.x;
  this.y                = position.y;
  this.value            = value || 2;

  this.previousPosition = null;
  this.mergedFrom       = null; // Tracks tiles that merged together
}

Tile.prototype.savePosition = function () {
  this.previousPosition = { x: this.x, y: this.y };
};

Tile.prototype.updatePosition = function (position) {
  this.x = position.x;
  this.y = position.y;
};

Tile.prototype.serialize = function () {
  return {
    position: {
      x: this.x,
      y: this.y
    },
    value: this.value
  };
};

function GameController(grid) {
  if (grid) {
    this.size = grid.size;
    this.grid = grid;
  }
}

// Save all tile positions and remove merger info
GameController.prototype.prepareTiles = function () {
  this.grid.eachCell(function (x, y, tile) {
    if (tile) {
      tile.mergedFrom = null;
      tile.savePosition();
    }
  });
};

// Move a tile and its representation
GameController.prototype.moveTile = function (tile, cell) {
  this.grid.cells[tile.x][tile.y] = null;
  this.grid.cells[cell.x][cell.y] = tile;
  tile.updatePosition(cell);
};

// Move tiles on the grid in the specified direction
GameController.prototype.moveTiles = function (direction) {
  // 0: up, 1: right, 2: down, 3: left
  var self = this;

  if (this.over) return; // Don't do anything if the game's over

  var cell, tile;

  var vector     = this.getVector(direction);
  var traversals = this.buildTraversals(vector);
  var moved      = false;

  // Save the current tile positions and remove merger information
  this.prepareTiles();

  // Traverse the grid in the right direction and move tiles
  traversals.x.forEach(function (x) {
    traversals.y.forEach(function (y) {
      cell = { x: x, y: y };
      tile = self.grid.cellContent(cell);

      if (tile) {
        var positions = self.findFarthestPosition(cell, vector);
        var next      = self.grid.cellContent(positions.next);

        // Only one merger per row traversal?
        if (next && next.value === tile.value && !next.mergedFrom) {
          var merged = new Tile(positions.next, tile.value * 2);
          merged.mergedFrom = [tile, next];

          self.grid.insertTile(merged);
          self.grid.removeTile(tile);

          // Converge the two tiles' positions
          tile.updatePosition(positions.next);

          // Update the score
          self.score += merged.value;
        } else {
          self.moveTile(tile, positions.farthest);
        }

        if (!self.positionsEqual(cell, tile)) {
          moved = true; // The tile moved from its original cell!
        }
      }
    });
  });
  return moved;
}

// Determine whether a move is available
GameController.prototype.moveAvailable = function (direction) {
  // 0: up, 1: right, 2: down, 3: left
  var tile;
  var vector = this.getVector(direction);
  for (var x = 0; x < this.size; x++) {
    for (var y = 0; y < this.size; y++) {
      tile = this.grid.cellContent({ x: x, y: y });

      if (tile) {
        var cell   = { x: x + vector.x, y: y + vector.y };
        if (!this.grid.withinBounds(cell))
          continue;

        var otherTile  = this.grid.cellContent(cell);

        // The current tile can be moved if the cell is empty or has the same value.
        if (!otherTile || otherTile.value === tile.value) {
          return true;
        }
      }
    }
  }
  return false;
};

// Adds a tile to the grid
GameController.prototype.addTile = function (tile) {
  this.grid.insertTile(tile);
  if (!this.movesAvailable()) {
    this.over = true; // Game over!
  }
};

// Get the vector representing the chosen direction
GameController.prototype.getVector = function (direction) {
  // Vectors representing tile movement
  var map = {
    0: { x: 0,  y: -1 }, // Up
    1: { x: 1,  y: 0 },  // Right
    2: { x: 0,  y: 1 },  // Down
    3: { x: -1, y: 0 }   // Left
  };

  return map[direction];
};

// Build a list of positions to traverse in the right order
GameController.prototype.buildTraversals = function (vector) {
  var traversals = { x: [], y: [] };

  for (var pos = 0; pos < this.size; pos++) {
    traversals.x.push(pos);
    traversals.y.push(pos);
  }
  
  // Always traverse from the farthest cell in the chosen direction
  if (vector.x === 1) traversals.x = traversals.x.reverse();
  if (vector.y === 1) traversals.y = traversals.y.reverse();

  return traversals;
};

GameController.prototype.findFarthestPosition = function (cell, vector) {
  var previous;

  // Progress towards the vector direction until an obstacle is found
  do {
    previous = cell;
    cell     = { x: previous.x + vector.x, y: previous.y + vector.y };
  } while (this.grid.withinBounds(cell) &&
           this.grid.cellAvailable(cell));

  return {
    farthest: previous,
    next: cell // Used to check if a merge is required
  };
};

GameController.prototype.movesAvailable = function () {
  return this.grid.cellsAvailable() || this.tileMatchesAvailable();
};

// Check for available matches between tiles (more expensive check)
GameController.prototype.tileMatchesAvailable = function () {
  var self = this;

  var tile;

  for (var x = 0; x < this.size; x++) {
    for (var y = 0; y < this.size; y++) {
      tile = this.grid.cellContent({ x: x, y: y });

      if (tile) {
        for (var direction = 0; direction < 4; direction++) {
          var vector = self.getVector(direction);
          var cell   = { x: x + vector.x, y: y + vector.y };

          var other  = self.grid.cellContent(cell);

          if (other && other.value === tile.value) {
            return true; // These two tiles can be merged
          }
        }
      }
    }
  }

  return false;
};

GameController.prototype.positionsEqual = function (first, second) {
  return first.x === second.x && first.y === second.y;
};

function GameManager(size, actuator, syncHelper) {
  this.size           = size; // Size of the grid
  this.actuator       = actuator;
  this.syncHelper     = syncHelper;

  this.startTiles = 2;
  this.lastDirection = 0;
}

// GameManager inherits from GameController
GameManager.prototype = new GameController();

// Restart the game
GameManager.prototype.restart = async function () {
  this.actuator.continueGame(); // Clear the game won/lost message
  await this.setup();
};


// Set up the game
GameManager.prototype.setup = async function () {
  this.grid        = new Grid(this.size);
  this.score       = 0;
  this.over        = false;

  // Add the initial tiles
  await this.addStartTiles();

  // Update the actuator
  this.actuate();
};

// Set up the initial tiles to start the game with
GameManager.prototype.addStartTiles = async function () {
  if (await this.syncTiles(true, 0)) {
    return;
  }
  for (var i = 0; i < this.startTiles; i++) {
    this.generateTile();
  }
};

// Adds a tile in a random position
GameManager.prototype.addRandomTile = function () {
  if (this.grid.cellsAvailable()) {
    var value = Math.random() < 0.9 ? 2 : 4;
    var tile = new Tile(this.grid.randomAvailableCell(), value);

    this.addTile(tile);
  }
};

// Adds a tile in (hopefully) the worst position possible
GameManager.prototype.addEvilTile = function() {
  var self = this;
  if (this.grid.cellsAvailable()) {
    // Strategy: place the new tile along the edge of the last direction the player pressed.
    // This forces the player to press a different direction.
    // Also, place the new tile next to the largest number possible.
    var vector = this.getVector(this.lastDirection);
    // Flip the direction
    vector.x *= -1;
    vector.y *= -1;

    // Build an array next available cells in the direction specified.
    var cellOptions = [];
    for (var i = 0; i < this.size; i++) {
      for (var j = 0; j < this.size; j++) {
        var cell = { x: 0, y: 0 };
        if (vector.x == 1)
          cell.x = j;
        else if (vector.x == -1)
          cell.x = this.size - j - 1;
        else
          cell.x = i;
        if (vector.y == 1)
          cell.y = j;
        else if (vector.y == -1)
          cell.y = this.size - j - 1;
        else
          cell.y = i;
        if (this.grid.cellAvailable(cell)) {
          cellOptions.push(cell);
          break;
        }
      }
    }
    // Find the available cell with the best score
    var bestScore = 0;
    var winners = [];
    var maxTileValue = Math.pow(2, this.size * this.size);
    for (i = 0; i < cellOptions.length; i++) {
      // Look at the surrounding cells
      var minValue = maxTileValue;
      for (var direction = 0; direction < 4; direction++) {
        var adjVector = this.getVector(direction);
        var adjCell = {
          x: cellOptions[i].x + adjVector.x,
          y: cellOptions[i].y + adjVector.y
        };
        var adjTile = this.grid.cellContent(adjCell);
        if (adjTile) {
          minValue = Math.min(minValue, adjTile.value);
        }
      }
      if (minValue > bestScore) {
        winners = [];
        bestScore = minValue;
      }
      if (minValue >= bestScore) {
        winners.push(cellOptions[i]);
      }
    }
    if (winners.length) {
      var winnerIndex = Math.floor(Math.random() * winners.length);
      var value = (bestScore != 2 ? 2 : 4);
      var tile = new Tile(winners[winnerIndex], value);
      this.addTile(tile);
    }
  }
};

GameManager.prototype.generateTile = GameManager.prototype.addRandomTile;

// Sends the updated grid to the actuator
GameManager.prototype.actuate = function (force = false) {
  this.actuator.actuate(this.grid, {
    score:      this.score,
    over:       this.over
  }, force);
};

// Represent the current game as an object
GameManager.prototype.serialize = function () {
  return {
    grid:        this.grid.serialize(),
    score:       this.score,
    over:        this.over
  };
};

GameManager.prototype.syncTiles = async function (isStart, move) {
  if (!this.syncHelper) return false;
  const gameStatus = await this.syncHelper.syncTiles(this.serialize(), isStart, move);
  if (!gameStatus) return false;
  this.grid        = new Grid(gameStatus.grid.size, gameStatus.grid.cells);
  this.score       = gameStatus.score;
  this.over        = !this.movesAvailable();
  return true;
};

// Move tiles on the grid in the specified direction
GameManager.prototype.move = async function (direction) {
  // 0: up, 1: right, 2: down, 3: left
  var moved = this.moveTiles(direction);

  if (moved) {
    this.lastDirection = direction;
    if (!await this.syncTiles(false, direction)) {
      this.generateTile();
    }
    this.actuate();
  }
};

// This AI follows a hard-coded strategy based on the programmer's experience.
// It is not a trained AI.

GoalType = { UNDEFINED: -1, BUILD: 0, SHIFT: 1, MOVE: 2 };

Goal = function() {
};
Goal.prototype = {
  type: GoalType.UNDEFINED
};

RNGAI = function (game) {
  this.game = game;
};
RNGAI.prototype.nextMove = function() {
  // Move in a random direction.
  var move;
  do {
    move = Math.floor(Math.random() * 4);
  } while (!this.game.moveAvailable(move));
  return move;
};

PriorityAI = function (game) {
  this.game = game;
};
PriorityAI.prototype.nextMove = function() {
  // Move based on priority: up, left, right, down
  var priority = [0, 3, 1, 2];
  var move;
  for (var i = 0; i < priority.length; i++) {
    move = priority[i];
    if (this.game.moveAvailable(move)) {
      return move;
    }
  }
  return 0;
}

AlgorithmAI = function (game) {
  this.game = game;
};
AlgorithmAI.prototype.prevMove = -1;
AlgorithmAI.prototype.nextMove = function() {
  // Move based on an algorithm: up, left, up, left, etc.
  // If neither move is available then go right or down.
  var move = 0;
  if (move == this.prevMove)
    move = 3;
  
  if (!this.game.moveAvailable(move)) {
    // Revert to priority mode
    var priority = [0, 3, 1, 2];
    for (var i = 0; i < priority.length; i++) {
      move = priority[i];
      if (this.game.moveAvailable(move))
        break;
    }
  }
  this.prevMove = move;
  return move;
}

SmartAI = function(game) {
  this.game = game;
};

SmartAI.prototype.nextMove = function() {
  // Determine the best move given the current game state
  // Use a couple of stragtegies:
  // 1. Goals:
  //   - Determine the main goal given the current board state
  //     (e.g. if the highest number is 64, build it up to 128)
  //   - Determine sub-goals that must happen to achieve that goal
  // 2. Planning ahead
  //   - in some cases, the AI should plan ahead a certain number of
  //     moves to determine the effect of each possible move it can make.
  //     If it sees that a certain move will put the board in a bad state
  //     (i.e. forced to push the wrong direction), then it will avoid that
  //     move. Alternatively, if it sees a sequence of moves that will 
  //     accomplish a goal, it will do those moves.
  /*var goal = this.determineGoal(this.game.grid);
  // Keep looking at sub-goals until we find a sub-goal that is a simple movement.
  while (goal.type != GoalType.MOVE) {
    goal = this.determineSubGoal(this.game.grid, goal);
  }
  
  if (goal.directions) {
    // Move in the most optimal legal direction.
    for (var i = 0; i < goal.directions.length; i++) {
      if (this.game.moveAvailable(goal.directions[i])) {
        return goal.directions[i];
      }
    }
  }*/
  
  // Plan ahead a few moves in every direction and analyze the board state.
  // Go for moves that put the board in a better state.
  var originalQuality = this.gridQuality(this.game.grid);
  var results = this.planAhead(this.game.grid, 3, originalQuality);
  // Choose the best result
  var bestResult = this.chooseBestMove(results, originalQuality);
  
  return bestResult.direction;
};

// Plans a few moves ahead and returns the worst-case scenario grid quality,
// and the probability of that occurring, for each move
SmartAI.prototype.planAhead = function(grid, numMoves, originalQuality) {
  var results = new Array(4);
  
  // Try each move and see what happens.
  for (var d = 0; d < 4; d++) {
    // Work with a clone so we don't modify the original grid.
    var testGrid = grid.clone();
    var testGame = new GameController(testGrid);
    var moved = testGame.moveTiles(d);
    if (!moved) {
      results[d] = null;
      continue;
    }
    // Spawn a 2 in all possible locations.
    var result = {
      quality: -1,    // Quality of the grid
      probability: 1, // Probability that the above quality will happen
      qualityLoss: 0, // Sum of the amount that the quality will have decreased multiplied by the probability of the decrease
      direction: d
    };
    var availableCells = testGrid.availableCells();
    for (var i = 0; i < availableCells.length; i++) {
      // Assume that the worst spawn location is adjacent to an existing tile,
      // and only test cells that are adjacent to a tile.
      var hasAdjacentTile = false;
      for (var d2 = 0; d2 < 4; d2++) {
        var vector = testGame.getVector(d2);
        var adjCell = {
          x: availableCells[i].x + vector.x,
          y: availableCells[i].y + vector.y,
        };
        if (testGrid.cellContent(adjCell)) {
          hasAdjacentTile = true;
          break;
        }
      }
      if (!hasAdjacentTile)
        continue;

      var testGrid2 = testGrid.clone();
      var testGame2 = new GameController(testGrid2);
      testGame2.addTile(new Tile(availableCells[i], 2));
      var tileResult;
      if (numMoves > 1) {
        var subResults = this.planAhead(testGrid2, numMoves - 1, originalQuality);
        // Choose the sub-result with the BEST quality since that is the direction
        // that would be chosen in that case.
        tileResult = this.chooseBestMove(subResults, originalQuality);
      } else {
        var tileQuality = this.gridQuality(testGrid2);
        tileResult = {
          quality: tileQuality,
          probability: 1,
          qualityLoss: Math.max(originalQuality - tileQuality, 0)
        };
      }
      // Compare this grid quality to the grid quality for other tile spawn locations.
      // Take the WORST quality since we have no control over where the tile spawns,
      // so assume the worst case scenario.
      if (result.quality == -1 || tileResult.quality < result.quality) {
        result.quality = tileResult.quality;
        result.probability = tileResult.probability / availableCells.length;
      } else if (tileResult.quality == result.quality) {
        result.probability += tileResult.probability / availableCells.length;
      }
      result.qualityLoss += tileResult.qualityLoss / availableCells.length;
    }
    results[d] = result;
  }
  return results;
}

SmartAI.prototype.chooseBestMove = function(results, originalQuality) {
  // Choose the move with the least probability of decreasing the grid quality.
  // If multiple results have the same probability, choose the one with the best quality.
  var bestResult;
  for (i = 0; i < results.length; i++) {  
    if (results[i] == null)
      continue;
    if (!bestResult ||
        results[i].qualityLoss < bestResult.qualityLoss ||
        (results[i].qualityLoss == bestResult.qualityLoss && results[i].quality > bestResult.quality) ||
        (results[i].qualityLoss == bestResult.qualityLoss && results[i].quality == bestResult.quality && results[i].probability < bestResult.probability)) {
      bestResult = results[i];
    }
  }
  if (!bestResult) {
    bestResult = {
      quality: -1,
      probability: 1,
      qualityLoss: originalQuality,
      direction: 0
    };
  }
  return bestResult;
}

// Gets the quality of the current state of the grid
SmartAI.prototype.gridQuality = function(grid) {
  /* Look at monotonicity of each row and column and sum up the scores.
   * (monoticity = the amount to which a row/column is constantly increasing or decreasing)
   *
   * How monoticity is scored (may be subject to modification):
   *   score += current_tile_value
   *   -> If a tile goes againt the monoticity direction:
   *      score -= max(current_tile_value, prev_tile_value)
   *
   * Examples:
   *   2    128    64   32
   *  +2     +0   +64  +32
   
   *  32     64   128    2
   * +32    +64  +128 -126
   *
   *   128   64   32   32
   *  +128  +64  +32  +32
   * 
   *   ___  128   64   32
   *    +0   +0  +64  +32
   *
   *   128   64   32  ___
   *  +128  +64  +32
   *
   *   ___  128  ___  ___
   *         +0
   *
   *   ___  128  ___  32
   *         +0      +32
   */
  var monoScore = 0; // monoticity score
  var traversals = this.game.buildTraversals({x: -1, y:  0});
  var prevValue = -1;
  var incScore = 0, decScore = 0;
  
  var scoreCell = function(cell) {
    var tile = grid.cellContent(cell);
    var tileValue = (tile ? tile.value : 0);
    incScore += tileValue;
    if (tileValue <= prevValue || prevValue == -1) {
      decScore += tileValue;
      if (tileValue < prevValue) {
        incScore -= prevValue;
      }
    }
    prevValue = tileValue;
  };
  
  // Traverse each column
  traversals.x.forEach(function (x) {
    prevValue = -1;
    incScore = 0;
    decScore = 0;
    traversals.y.forEach(function (y) {
      scoreCell({ x: x, y: y });
    });
    monoScore += Math.max(incScore, decScore);
  });
  // Traverse each row
  traversals.y.forEach(function (y) {
    prevValue = -1;
    incScore = 0;
    decScore = 0;
    traversals.x.forEach(function (x) {
      scoreCell({ x: x, y: y });
    });
    monoScore += Math.max(incScore, decScore);
  });
  
  // Now look at number of empty cells. More empty cells = better.
  var availableCells = grid.availableCells();
  var emptyCellWeight = 8;
  var emptyScore = availableCells.length * emptyCellWeight;
  
  var score = monoScore + emptyScore;
  return score;
}

// Determine the main (highest level) goal to accomplish for the current grid
SmartAI.prototype.determineGoal = function(grid) {
  var goal = new Goal();
  // Find the highest tile on the board.
  var maxValue = 0;
  var maxCells = [];
  grid.eachCell(function(x, y, tile) {
    if (tile && tile.value >= maxValue) {
      if (tile.value > maxValue) {
        maxCells = [];
        maxValue = tile.value;
      }
      maxCells.push({x: x, y: y});
    }
  });
  var maxCell;
  if (maxCells.length == 1) {
    maxCell = maxCells[0];
  } else {
    // If there are multiple cells with the highest value, choose the one closest to the corner
    var minDist = grid.size;
    for (var i = 0; i < maxCells.length; i++) {
      dist = Math.min(maxCells[i].x, grid.size - maxCells[i].x - 1)
           + Math.min(maxCells[i].y, grid.size - maxCells[i].y - 1);
      if (dist < minDist) {
        minDist = dist;
        maxCell = maxCells[i];
      }
    }
  }
  // Find the distance of the max tile from the corner
  dist = Math.min(maxCell.x, grid.size - maxCell.x - 1)
       + Math.min(maxCell.y, grid.size - maxCell.y - 1);
  if (dist == 0) {
    // Great! The tile is in a corner.
    // In this case, the goal is to double that tile's value.
    goal.type = GoalType.BUILD;
    goal.cell = maxCell;
    goal.value = maxValue * 2;
    return goal;
  }
  // Shoot, the highest tile is not in the corner.
  // Find a way to get it in the corner.
  if (dist == 1) {
    if (maxValue <= 512) {
      // Option 1: build up the corner tile to have the same value as the max tile
      // This is only reasonable if the tile value is not greater than 512.
      goal.type = GoalType.BUILD;
      goal.cell = { x: (maxCell.x < grid.size / 2 ? 0 : grid.size - 1),
                    y: (maxCell.y < grid.size / 2 ? 0 : grid.size - 1) };
      goal.value = maxValue;
      return goal;
    }
    // Things are looking pretty rough.
    // Option 2: do some fancy moves to try and shift the max tile into a different corner.
    // This is only reasonable if there are enough open cells.
    var availableCells = game.grid.availableCells();
    if (availableCells.length > 4) {
      // TODO: if the target cell is empty, just move! (don't shift)
      goal.type = GoalType.SHIFT;
      goal.fromCell = maxCell;
      if (maxCell.x == 0 || maxCell.x == game.size - 1) {
        goal.cell = { x: maxCell.x,
                      y: (maxCell.y < grid.size / 2 ? grid.size - 1: 0) };
      } else {
        goal.cell = { x: (maxCell.x < grid.size / 2 ? grid.size - 1 : 0),
                      y: maxCell.y };
      }
      return goal;
    }
    // Now things are looking REALLY rough.
    // Option 3: Our best bet is to try and build up the max tile to clear up room on the board.
    goal.type = GoalType.BUILD;
    goal.cell = maxCell;
    goal.value = maxValue * 2;
    return goal;
  }
  // dist > 1
  // The cell is really far from a corner, which sucks.
  // Do some fancy moves to try and shift the max tile into a different corner.
  var availableCells = game.grid.availableCells();
  goal.type = GoalType.SHIFT;
  goal.fromCell = maxCell;
  goal.cell = { x: maxCell.x,
                y: (maxCell.y < grid.size / 2 ? grid.size - 1: 0) };
  return goal;
};

// Determine the sub-goal required to achieve the current goal.
SmartAI.prototype.determineSubGoal = function(grid, goal) {
  var subgoal = new Goal();
  if (goal.type == GoalType.BUILD) {
    var tile = grid.cellContent(goal.cell);
    
    if (!tile) {
      // Cell is empty. This is easy; just move a tile into that cell.
      goal.type = GoalType.MOVE;
      vector = { x: goal.cell.x - grid.size / 2,
                 y: goal.cell.y - grid.size / 2 };
      goal.directions = this.getDirections(vector);
      return goal;
    }
    
    // See if any adjacent cells have equal value.
    var adjacentCells = new Array(4);
    for (i = 0; i < 4; i++) {
      var vector = this.game.getVector(i);
      var adjCell = {x: goal.cell.x + vector.x, y: goal.cell.y + vector.y };
      var adjTile = grid.cellContent(adjCell);
      if (adjTile && adjTile.value == tile.value) {
        // Adjacent tiles with equal value. Combine the tiles.
        // Flip the vector and use that as the direction.
        vector.x = -vector.x;
        vector.y = -vector.y;
        goal.type = GoalType.MOVE;
        goal.directions = this.getDirections(vector);
        return goal;
      }
    }
    
    // No tiles to combine. Start building an adjacent tile.
    
  } else if (goal.type == GoalType.MOVE) {
  }
  return subgoal;
};

// Gets the direction of movement priority order given a vector
SmartAI.prototype.getDirections = function(vector) {
  directions = [0, 3, -1, -1];
  if (vector.x > 0) {
    directions[0] = 2;
  }
  if (vector.y > 0) {
    directions[1] = 1;
  }
  if (Math.abs(vector.x) > Math.abs(vector.y)) {
    var temp = directions[0];
    directions[0] = directions[1];
    directions[1] = temp;
  }
  directions[2] = (directions[1] + 2) % 4;
  directions[3] = (directions[0] + 2) % 4;
}

ConsoleActuator = function(show, forEach, showOver) {
  this.show = show;
  this.cnt = 0;
  this.forEach = forEach;
  this.showOver = showOver;
};

ConsoleActuator.prototype.actuate = function(grid, metadata, force) {
  ++this.cnt;
  if (this.show && (!this.forEach || this.cnt % this.forEach == 0 || (metadata.over && this.showOver) || force)) {
    console.log("Count: " + this.cnt);
    console.log("Score: " + metadata.score);
    console.log("Over: " + metadata.over);
    console.log(grid.cells.map(line => line.map(item => (item ? item.value.toString() : '').padStart(4, ' ')).join(' | ')).join('\n'));
  }
};

ConsoleActuator.prototype.continueGame = function() {
  this.cnt = 0;
  if (this.show) {
    console.log("New game");
  }
}

const Converter = {
  cells2List(cells) {
    const ret = [];
    cells.forEach(line => line.forEach(item => ret.push(item ? item.value : 0)));
    return ret;
  },
  cells2Matrix(cells) {
    return cells.map(line => line.map(item => item ? item.value : 0));
  },
  grid2List(grid) {
    return this.cells2List(grid.cells);
  },
  grid2Matrix(grid) {
    return this.cells2Matrix(grid.cells);
  },
  matrix2Grid(matrix) {
    return {
      size: matrix.length,
      cells: matrix.map((line, x) => line.map((item, y) => item ? {
        position: {
          x: x,
          y: y
        },
        value: item
      } : null))
    };
  },
  list2Matrix(list, size) {
    if (list.length != size * size) {
      throw Error('Invalid list length');
    }
    const matrix = [];
    for (let i = 0; i < size; i++) {
      matrix.push(list.slice(i * size, (i + 1) * size));
    }
    return matrix;
  },
  list2Grid(list, size) {
    return this.matrix2Grid(this.list2Matrix(list, size), size);
  }
};

async function runAI(uid, onMoney, times = 1, show = true) {
  const { SessionFetch } = await import('./session_fetcher.mjs');
  const session = new SessionFetch('https://2024challenge.52pojie.cn/');
  session.addCookie('uid', uid, true);
  let stopAll = false;
  
  let game = new GameManager(4, new ConsoleActuator(show, 10, true), {
    async syncTiles(current, isStart, move) {
      // console.log(isStart, move);
      // return null;
      // isStart: true if sync for start, move is meaningless in this case
      // move: 0: up, 1: right, 2: down, 3: left
      let ret;
      if (isStart) {
        let resp = await session.fetch('/flagB/restart', {"method": "POST"});
        if (show) console.log('restart', await resp.text());
        resp = await session.fetch('/flagB/info', {"method": "GET"});
        let ret = await resp.json();
        stopAll = onMoney(ret.data.money_count ?? 0);
        return {grid: Converter.list2Grid(ret.data.game_data.tiles, 4), score: ret.data.game_data.score ?? 0};
      }
      // console.log('mooving', move)
      resp = await session.fetch('/flagB/move', {
        "method": "POST",
        "headers": {
          "content-type": "application/x-www-form-urlencoded"
        },
        "body": "direction=" + [3 /* left */, 2 /* down */, 4 /* right */, 1 /* up */][move]
      });
      ret = await resp.json();
      stopAll = onMoney(ret.data.money_count ?? 0);
      // console.log(current.score, ret.data.game_data.score, Converter.grid2Matrix(current.grid));
      return {grid: Converter.list2Grid(ret.data.game_data.tiles, 4), score: ret.data.game_data.score ?? 0};
    }
  });
  let ai = new SmartAI(game);
  while (!stopAll) {
    await game.restart();
    while (!game.over && !stopAll) {
      await game.move(ai.nextMove());
    }
    if (!stopAll && times) {
      times--;
      if (!times) stopAll = true;
    }
  }
  game.actuate(true);
  return session;
}

if (module) module.exports = { runAI };
