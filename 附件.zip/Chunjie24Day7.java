package com.pojie52;

import capstone.api.Instruction;
import com.github.unidbg.AndroidEmulator;
import com.github.unidbg.LibraryResolver;
import com.github.unidbg.Module;
import com.github.unidbg.Symbol;
import com.github.unidbg.arm.backend.Backend;
import com.github.unidbg.arm.backend.CodeHook;
import com.github.unidbg.arm.backend.ReadHook;
import com.github.unidbg.arm.backend.UnHook;
import com.github.unidbg.arm.context.RegisterContext;
import com.github.unidbg.debugger.Debugger;
import com.github.unidbg.linux.android.AndroidEmulatorBuilder;
import com.github.unidbg.linux.android.AndroidResolver;
import com.github.unidbg.linux.android.dvm.DalvikModule;
import com.github.unidbg.linux.android.dvm.DvmClass;
import com.github.unidbg.linux.android.dvm.VM;
import com.github.unidbg.linux.file.MapsFileIO;
import com.github.unidbg.memory.Memory;
import com.github.unidbg.pointer.UnidbgPointer;
import com.github.unidbg.spi.HookedSymbol;
import com.github.unidbg.utils.Inspector;
import com.github.unidbg.virtualmodule.android.Camera2NdkModule;
import com.sun.jna.Pointer;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import unicorn.Arm64Const;

import java.io.File;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.*;
import java.util.stream.Collectors;

public class Chunjie24Day7 {
    public static byte[] getMd5(String str) {
        try {
            return MessageDigest.getInstance("MD5").digest(str.getBytes());
        } catch (Exception unused) {
            return null;
        }
    }

    public static byte[] getMd5(byte[] bytes) {
        try {
            return MessageDigest.getInstance("MD5").digest(bytes);
        } catch (Exception unused) {
            return null;
        }
    }

    public static String[] getOpInfo(Instruction inst) {
        return inst.getOpStr().split(", ");
    }

    public static void throwError(String desc) {
        try {
            throw new RuntimeException(desc);
        } catch (RuntimeException err) {
            err.printStackTrace(System.err);
            System.exit(-1);
        }
    }

    public static void main(String[] args) {
        final AndroidEmulator emulator = AndroidEmulatorBuilder
//                .for32Bit()
                .for64Bit()
                .setProcessName("com.wuaipojie.crackme2024")
                .build();

        Level level = Level.DEBUG;
//        level = Level.ERROR;

        Logger.getLogger("com.github.unidbg.linux.ARM32SyscallHandler").setLevel(level);
        Logger.getLogger("com.github.unidbg.linux.ARM64SyscallHandler").setLevel(level);
        Logger.getLogger("com.github.unidbg.unix.UnixSyscallHandler").setLevel(level);
        Logger.getLogger("com.github.unidbg.AbstractEmulator").setLevel(level);
        Logger.getLogger("com.github.unidbg.linux.android.dvm.DalvikVM").setLevel(level);
        Logger.getLogger("com.github.unidbg.linux.android.dvm.BaseVM").setLevel(level);
        Logger.getLogger("com.github.unidbg.linux.android.dvm").setLevel(level);
        Logger.getLogger("com.github.unidbg.linux.android.SystemPropertyHook").setLevel(level);
        Logger.getLogger("com.github.unidbg.virtualmodule.android.Camera2NdkModule").setLevel(level);

        // required to read current apk
        // put base.apk at unidbg-android/src/main/resources/android/sdk23/data/app/~~HnABphG7Pe6-7EcBE4_uzg==/com.wuaipojie.crackme2024-KLWRM_cmdomPT0Z97Sa0ZQ==
        MapsFileIO.addLine("12345660-12345670 aaaa 123 aa aa /data/app/~~HnABphG7Pe6-7EcBE4_uzg==/com.wuaipojie.crackme2024-KLWRM_cmdomPT0Z97Sa0ZQ==/base.apk");

        final Memory memory = emulator.getMemory();
        LibraryResolver resolver = new AndroidResolver(23);
        memory.setLibraryResolver(resolver);
        final VM vm = emulator.createDalvikVM();
        vm.setVerbose(true);
        final Backend backend = emulator.getBackend();

        // require libcamera2ndk with 2 camera at the end
        new Camera2NdkModule(emulator, vm).register(memory);
        DalvikModule dm = vm.loadLibrary(new File("unidbg-android/src/test/resources/example_binaries/arm64-v8a/lib52pojie.so"), true);
        Module module = dm.getModule();
        Symbol onLoad = module.findSymbolByName("JNI_OnLoad", false);
        System.out.println("JNI_OnLoad address: 0x" + Long.toHexString(onLoad.getAddress()));
        final DvmClass cNative = vm.resolveClass("com/wuaipojie/crackme2024/MainActivity");

        // hook to given range of address to log its read records
        class ReadMap implements Comparable<ReadMap> {
            public final long address, pc;
            public final int size;

            public ReadMap(long address, long pc, int size) {
                this.address = address;
                this.pc = pc;
                this.size = size;
            }

            @Override
            public int compareTo(ReadMap o) {
                return (int) (this.address - o.address);
            }

            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (!(o instanceof ReadMap readMap)) return false;
                return address == readMap.address && pc == readMap.pc && size == readMap.size;
            }

            @Override
            public int hashCode() {
                return Objects.hash(address, pc, size);
            }
        }
        final List<ReadMap> rml = new ArrayList<>();
        backend.hook_add_new(new ReadHook() {
            private UnHook unHook;
            @Override
            public void hook(Backend backend, long address, int size, Object user) {
//                System.out.println("read at " + Long.toHexString(address));
//                System.out.println("PC at " + Long.toHexString(backend.reg_read(Arm64Const.UC_ARM64_REG_PC).longValue()));
                rml.add(new ReadMap(address, backend.reg_read(Arm64Const.UC_ARM64_REG_PC).longValue(), size));
            }

            @Override
            public void onAttach(UnHook unHook) {
                this.unHook = unHook;
            }

            @Override
            public void detach() {
                unHook.unhook();
            }
        }, module.base + 0x41310, module.base + 0x41555, emulator);

        // call JNI_OnLoad
        dm.callJNI_OnLoad(emulator);

        // custom to trace somethings
        try {
//            emulator.traceCode(module.base,module.base + module.size);
//            emulator.traceCode(module.base,module.base + module.size).setRedirect(new PrintStream("E:\\trace_code.log"));
//            emulator.traceWrite(module.base,module.base + module.size).setRedirect(new PrintStream("E:\\trace_write.log"));
//            emulator.traceRead(module.base,module.base + module.size).setRedirect(new PrintStream("E:\\trace_read.log"));
            // Trace block
//            long begin = 0x40000000, end = 0x40000000+0x5A328;
//            final AssemblyCodeDumper hook = new AssemblyCodeDumper(emulator, begin, end, null);
//            emulator.getBackend().hook_add_new(new BlockHook() {
//                @Override
//                public void hookBlock(Backend backend, long address, int size, Object user) {
//                    System.out.println(Long.toHexString(address));
//                    //                    hook.hook(backend, address, size, user);
//                }
//                @Override
//                public void onAttach(UnHook unHook) {
//                    hook.onAttach(unHook);
//                }
//                @Override
//                public void detach() {
//                    hook.detach();
//                }
//            }, begin, end, emulator);
        } catch (Exception err) {
            err.printStackTrace(System.err);
        }

        // instruction level hooks
        class MapValue {
            public Instruction ins;
            public boolean isCSel = false;
            public boolean isBLR = false;
            public long BLRTarget = 0;
            public Set<Long> jumpRecord = null;
            public String opStr = "";
            public Instruction brIns;

            public static class Case {
                long jumpTarget = 0;
            }

            public final Case[] cases = new Case[2];
        }
        class Mutable {
            public MapValue writeBLR;
            public long opCnt;
            public boolean afterBR;
            public boolean curCase;
            public boolean testCase;
            public long context;
            public MapValue curInst;
            public List<Long> list;
            public Instruction lastBR;
            public Set<Long> recordPCTo;

            public void reset() {
                opCnt = 0;
                testCase = false;
                afterBR = false;
                curCase = false;
                curInst = null;
                lastBR = null;
                list = new ArrayList<>();
                recordPCTo = null;
                writeBLR = null;
            }
        }
        final Map<Long, MapValue> map = new HashMap<>();
        final Mutable mutable = new Mutable();
        mutable.reset();
        final Debugger debugger = emulator.attach();
        class Hooks {
            CodeHook metaHook;
            CodeHook triggerHook;
            boolean usingBasicHook;
            int hitCnt;
            int pingCnt;
            StringBuilder sb;
        }
        final Hooks hooks = new Hooks();
        hooks.hitCnt = 0;
        hooks.pingCnt = 0;
        hooks.sb = new StringBuilder();
        hooks.usingBasicHook = false;
        final Map<Integer, Long> breakable = new HashMap<>();
        final Map<Integer, Long> skipTo = new HashMap<>();
        // breakable map is optimize for speed
        breakable.put(2796, module.base + 0x25be4L); skipTo.put(2796, 1438674L);
        breakable.put(6530, module.base + 0x26ddcL); skipTo.put(6530, 92080643L);
        breakable.put(9290, module.base + 0x173ecL); skipTo.put(9290, 92758971L);
        breakable.put(11068, module.base + 0x1fd40L); skipTo.put(11068, 93096934L);
        breakable.put(21296, module.base + 0x33788L); skipTo.put(21296, 95973298L);
        breakable.put(23545, module.base + 0x37c10L); skipTo.put(23545, 96557879L);
        breakable.put(23875, module.base + 0x37f90L); skipTo.put(23875, 99040106L);
        breakable.put(24336, module.base + 0x3b14cL); skipTo.put(24336, 99514669L);
        breakable.put(24435, module.base + 0x3d47cL); skipTo.put(24435, 99906096L);
        breakable.put(24488, module.base + 0x3aaf0L); skipTo.put(24488, 100699383L);
        breakable.put(24547, module.base + 0x3b66cL); skipTo.put(24547, 190746989L);
        breakable.put(24846, module.base + 0x3a8e0L); skipTo.put(24846, 191453889L);
        breakable.put(25297, module.base + 0x200dcL); skipTo.put(25297, 288469358L);
        breakable.put(25422, module.base + 0x20b7cL); skipTo.put(25422, 291622695L);
        hooks.metaHook = new CodeHook() {
            private UnHook unHook;

            @Override
            public void hook(Backend backend, long address, int size, Object user) {
                mutable.opCnt++;
                if (hooks.usingBasicHook) {
                    if (mutable.opCnt % 1000000 == 0) System.out.println("passing " + mutable.opCnt);
                    if (map.containsKey(address)) return;
                    hooks.usingBasicHook = false;
                }
                if (address == module.base + 0x1CEC8) {
                    // on checkSn handler
                    System.out.println("checkSn handle at " + backend.reg_read(Arm64Const.UC_ARM64_REG_W8).intValue());
                }
                if (address == module.base + 0x20F10) {
                    // on decryptInternal handler
                    System.out.println("decryptInternal handle at " + backend.reg_read(Arm64Const.UC_ARM64_REG_W10).intValue());
                }
                if (address == module.base + 0x1ADC0) {
                    // on JNI_OnLoad handler
                    System.out.println("JNI_OnLoad handle at " + backend.reg_read(Arm64Const.UC_ARM64_REG_W10).intValue());
                }
                if (address == module.base + 0x18080) {
                    // on getSigHash handler
                    System.out.println("getSigHash handle at " + backend.reg_read(Arm64Const.UC_ARM64_REG_W8).intValue());
                }
                if (address == module.base + 0x1C65C) {
                    // on internal 1(check adbd) ret
                    System.out.println("internal ret " + backend.reg_read(Arm64Const.UC_ARM64_REG_X0));
                }
                if (address == module.base + 0x20AFC) {
                    System.out.println("special point " + backend.reg_read(Arm64Const.UC_ARM64_REG_W10));
                    // if it is zero, decryptInternal will return success
//                    backend.reg_write(Arm64Const.UC_ARM64_REG_W10, 0);
                }
                if (mutable.recordPCTo != null) {
                    mutable.recordPCTo.add(address);
                    mutable.recordPCTo = null;
                }
                if (mutable.lastBR != null) {
                    backend.reg_write(Arm64Const.UC_ARM64_REG_X0 + Integer.parseInt(getOpInfo(mutable.lastBR)[0].substring(1), 10), 0xcccccccc);
                    mutable.lastBR = null;
                }
                if (mutable.testCase && mutable.afterBR) {
//                    System.out.println("rollback from " + Long.toHexString(address));
//                    System.out.flush();
                    long old = mutable.curInst.cases[mutable.curCase ? 1 : 0].jumpTarget;
                    if (old != 0 && old != address) {
                        throwError("bad address");
                    }
                    mutable.curInst.cases[mutable.curCase ? 1 : 0].jumpTarget = address;
                    mutable.afterBR = false;
                    backend.context_restore(mutable.context);
                    backend.context_free(mutable.context);
//                    System.out.println("PC -> " + Long.toHexString(backend.reg_read(Arm64Const.UC_ARM64_REG_PC).longValue()));
                    // PC should be set explicitly
                    backend.reg_write(Arm64Const.UC_ARM64_REG_PC, backend.reg_read(Arm64Const.UC_ARM64_REG_PC));
                    mutable.context = 0;
                    mutable.testCase = false;
                    mutable.curInst = null;
                    return;
                }
                if (!map.containsKey(address)) {
                    if (hooks.pingCnt >= 100000) {
                        System.out.println("FOUND new address: " + Long.toHexString(address) + " break the " + map.size() + ", " + mutable.opCnt);
                        hooks.sb.append(String.format("breakable.put(%d, module.base + 0x%sL); skipTo.put(%d, %dL);\n", map.size(), Long.toHexString(address - module.base), map.size(), mutable.opCnt));
                    }
                    hooks.pingCnt = 0;
                    var mv = new MapValue();
                    map.put(address, mv);
                    var res = emulator.disassemble(address, size, 1);
                    if (res == null || res.length != 1) {
                        throwError("bad length");
                    }
                    var ins = res[0];
                    mv.ins = ins;
                    var mnemonic = ins.getMnemonic();
                    var opStr = ins.getOpStr();
                    mv.opStr = opStr;
                    if (mnemonic.equals("blr")) {
                        mv.isBLR = true;
                    }
                    if (mnemonic.equals("csel") && (opStr.endsWith(", eq") || opStr.endsWith(", lt")) && opStr.contains("x")) {
                        mv.isCSel = true;
                        Instruction brIns;
                        String lastMne = "";
                        long offset = 4;
                        while (true) {
                            var br = emulator.disassemble(address + offset, 4, 1);
                            if (br == null || br.length != 1) {
                                throwError("re bad length");
                            }
                            brIns = br[0];
                            var brMnemonic = brIns.getMnemonic();
                            if (!brMnemonic.equals("ldr") && !brMnemonic.equals("add") && !brMnemonic.equals("br") && !brMnemonic.startsWith("mov") && !brMnemonic.equals("orr") && !brMnemonic.equals("ldur") && !brMnemonic.equals("stur")) {
                                System.out.println(Long.toHexString(brIns.getAddress()) + ": " + brMnemonic + " " + brIns.getOpStr());
                                throwError("bad inst");
                            }
                            if (brMnemonic.equals("movz") || brMnemonic.equals("movk")) {
                                mutable.list.add(brIns.getAddress());
                            }
                            if (brMnemonic.equals("br")) {
                                break;
                            }
                            lastMne = brMnemonic;
                            offset += 4;
                        }
                        if (!lastMne.equals("add")) {
                            var lastIns = emulator.disassemble(address + offset - 4, 4, 1);
                            if (lastIns == null || lastIns.length != 1) {
                                throwError("lastIns bad length");
                            }
                            System.out.println("PASSING pre inst " + Long.toHexString(lastIns[0].getAddress()) + ": " + lastIns[0].getMnemonic() + " " + lastIns[0].getOpStr());
                            if (0x31AF0 + module.base != brIns.getAddress()) {
                                throwError("bad pre inst");
                            }
                        }
                        mv.brIns = brIns;
                    }
                } else {
                    hooks.pingCnt++;
                    if (hooks.pingCnt == 100000 && !mutable.testCase && mutable.writeBLR == null) {
                        hooks.usingBasicHook = true;
                    }
                }
                if (breakable.containsKey(map.size())) {
                    hooks.hitCnt++;
                    if (hooks.hitCnt > 1000 && !mutable.testCase && mutable.writeBLR == null) {
                        long nextPC = breakable.get(map.size());
                        if (nextPC != 0) {
                            backend.hook_add_new(hooks.triggerHook, nextPC, nextPC, emulator);
                            if (skipTo.containsKey(map.size())) {
                                mutable.opCnt = skipTo.get(map.size());
                            }
                            unHook.unhook();
                        } else {
                            hooks.usingBasicHook = true;
                        }
                    }
                } else {
                    hooks.hitCnt = 0;
                }
                var cur = map.get(address);
                if (mutable.testCase && cur.ins.getMnemonic().equals("stur")) {
                    // pass stur in this case
                    System.out.println("PASSING " + Long.toHexString(cur.ins.getAddress()) + ": " + cur.ins.getMnemonic() + " " + cur.ins.getOpStr());
                    backend.reg_write(Arm64Const.UC_ARM64_REG_PC, backend.reg_read(Arm64Const.UC_ARM64_REG_PC).longValue() + 4);
                    return;
                }
                if (mutable.writeBLR != null) {
                    boolean near = cur.ins.getAddress() - 4 == mutable.writeBLR.ins.getAddress();
                    if (!near) {
                        if (mutable.writeBLR.BLRTarget != 0 && mutable.writeBLR.BLRTarget != address) {
                            throwError("bad BLR");
                        }
                        if (!cur.ins.getMnemonic().equals("stp")) {
//                        boolean near = cur.ins.getAddress() - 4 == mutable.writeBLR.ins.getAddress();
//                        System.out.println("NOT STP(" + Long.toHexString(cur.ins.getAddress()) + "): " + cur.ins.getMnemonic() + " " + cur.ins.getOpStr() + (near ? " near" : "") + " | " + mutable.opCnt + ", " + map.size());
//                        if (near) {
//                            // try to jump
//                            System.out.println("remove lr at " + Long.toHexString(address));
//                            backend.reg_write(Arm64Const.UC_ARM64_REG_LR, 0xbbbbbbbb);
//                            return;
//                        }
                        }
                        mutable.writeBLR.BLRTarget = address;
                    }
                    mutable.writeBLR = null;
                }
                if (cur.isBLR) {
                    mutable.writeBLR = cur;
                    if (!cur.opStr.startsWith("x")) {
                        throwError("bad JUMP for " + cur.opStr);
                    }
                    long target = backend.reg_read(Arm64Const.UC_ARM64_REG_X0 + Integer.parseInt(cur.opStr.substring(1))).longValue();
                    if (mutable.writeBLR.BLRTarget != 0 && mutable.writeBLR.BLRTarget != target) {
                        System.out.printf("pc: %x; lastBLR: %x; target: %x\n", address, mutable.writeBLR.BLRTarget, target);
                        throwError("bad BLR");
                    }
                    mutable.writeBLR.BLRTarget = target;
                    mutable.writeBLR = null;
                }
                if (cur.isCSel && !mutable.testCase) {
                    if (cur.cases[0] == null) {
//                        System.out.println(Long.toHexString(cur.ins.getAddress()) + " case 0");
//                        System.out.flush();
                        cur.cases[0] = new MapValue.Case();
                        mutable.testCase = true;
                        mutable.context = backend.context_alloc();
                        backend.context_save(mutable.context);
                        mutable.afterBR = false;
                        mutable.curCase = false;
                        mutable.curInst = cur;
                        backend.reg_write(Arm64Const.UC_ARM64_REG_NZCV, 0);
                    } else if (cur.cases[1] == null) {
//                        System.out.println(Long.toHexString(cur.ins.getAddress()) + " case 1");
//                        System.out.flush();
                        cur.cases[1] = new MapValue.Case();
                        mutable.testCase = true;
                        mutable.context = backend.context_alloc();
                        backend.context_save(mutable.context);
                        mutable.afterBR = false;
                        mutable.curCase = true;
                        mutable.curInst = cur;
                        backend.reg_write(Arm64Const.UC_ARM64_REG_NZCV, (1L << 30) | (1L << 31));
                    } else {
//                        System.out.println(Long.toHexString(cur.ins.getAddress()) + " case bypass");
//                        System.out.flush();
                    }
                }
//                if (cur.isCSel) {
//                    long nzcv = backend.reg_read(Arm64Const.UC_ARM64_REG_NZCV).longValue();
//                    // https://developer.arm.com/documentation/ddi0595/2021-06/AArch64-Registers/NZCV--Condition-Flags
//                    boolean flagN = (nzcv & (1L << 31)) != 0;
//                    boolean flagZ = (nzcv & (1L << 30)) != 0;
//                    boolean flagC = (nzcv & (1L << 29)) != 0;
//                    boolean flagV = (nzcv & (1L << 28)) != 0;
//                    // https://developer.arm.com/documentation/den0024/a/The-A64-instruction-set/Data-processing-instructions/Conditional-instructions
//                    boolean condMatch;
//                    if (cur.opStr.endsWith(", lt")) {
//                        condMatch = flagN != flagV;
//                    } else if (cur.opStr.endsWith(", eq")) {
//                        condMatch = flagZ;
//                    } else {
//                        throwError("bad cond");
//                    }
//                    if (mutable.curInst != null) {
//                        throwError("bad curInst");
//                    }
//                    mutable.afterBR = false;
//                    mutable.curCase = condMatch;
//                    mutable.curInst = cur;
//                    cur.cases[condMatch ? 1 : 0] = new MapValue.Case();
//                }
                if (mutable.testCase && mutable.curInst != null) {
                    if (mutable.curInst.brIns.getAddress() == address) {
                        if (cur.jumpRecord == null) {
                            cur.jumpRecord = new HashSet<>();
                        }
                        mutable.afterBR = true;
                    }
                }
                if (cur.jumpRecord != null) {
                    mutable.lastBR = cur.ins;
                    mutable.recordPCTo = cur.jumpRecord;
                }
            }

            @Override
            public void onAttach(UnHook unHook) {
                this.unHook = unHook;
            }

            @Override
            public void detach() {
                unHook.unhook();
            }
        };
        hooks.triggerHook = new CodeHook() {
            private UnHook unHook;

            @Override
            public void hook(Backend backend, long address, int size, Object user) {
                hooks.hitCnt = 0;
                backend.hook_add_new(hooks.metaHook, module.base, module.base + module.size, emulator);
                unHook.unhook();
                System.out.println("hit the address: " + Long.toHexString(address) + " break the " + map.size());
            }

            @Override
            public void onAttach(UnHook unHook) {
                this.unHook = unHook;
            }

            @Override
            public void detach() {
                unHook.unhook();
            }
        };
        backend.hook_add_new(hooks.metaHook, module.base, module.base + module.size, emulator);
        // hooks
        debugger.addBreakPoint(module.findSymbolByName("__system_property_get").getAddress(), (emulator2, address) -> {
            // change property read
            final RegisterContext context = emulator2.getContext();
            final String key = context.getPointerArg(0).getString(0);
            final Pointer retPtr = context.getPointerArg(1);
            System.out.println("read property: " + key);
            if (!key.equals("init.svc.adbd")) return true;
            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
                final String retStr = retPtr.getString(0);
                System.out.println("ret: " + retStr);
                if (retStr.equals("running")) {
                    System.out.println("matched. change to stopped");
                    retPtr.setString(0, "stopped");
                }
                return true;
            });
            return true;
        });
        debugger.addBreakPoint(module.base + 0x24290, (emulator2, address) -> {
            // decode base64 string
            final RegisterContext context = emulator2.getContext();
            System.out.println("0x24290 base64 decode");
            System.out.println("0x24290 inp: " + context.getPointerArg(0).getString(0));
            System.out.println("0x24290 inpLen: " + context.getLongArg(1));
            System.out.println("0x24290 ptr2size: " + context.getPointerArg(2));
            UnidbgPointer saved = context.getPointerArg(2);
            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
                long size = saved.getLong(0);
                Inspector.inspect(context.getPointerArg(0).getByteArray(0L, (int) size), "0x24290 alloc out");
                System.out.println("0x24290 size: " + size);
                return true;
            });
            return true;
        });
        debugger.addBreakPoint(module.base + 0x1E924, (emulator2, address) -> {
            // decryptInternal
            final RegisterContext context = emulator2.getContext();
            System.out.println("0x1E924 decryptInternal");
            System.out.println("0x1E924 const: " + context.getPointerArg(0).getLong(0));
            long size = context.getLongArg(2);
            System.out.println("0x1E924 inpLen: " + size);
            Inspector.inspect(context.getPointerArg(1).getByteArray(0L, (int) size), "0x1E924 inp");
            UnidbgPointer out = context.getPointerArg(3);
            System.out.println("0x1E924 out: " + out);
            Inspector.inspect(out.getByteArray(0L, 128), "0x1E924 out dump");
            System.out.println("0x1E924 ptr2size: " + context.getPointerArg(4).getLong(0));
            UnidbgPointer saved = context.getPointerArg(4);
            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
                System.out.println("0x1E924 retval: " + context.getLongArg(0));
                System.out.println("0x1E924 out size: " + saved.getLong(0));
                Inspector.inspect(out.getByteArray(0L, 128), "0x1E924 out dump ret");
                // passing logic
//                emulator1.getBackend().reg_write(Arm64Const.UC_ARM64_REG_X0, 0);
//                saved.setLong(0, 16);
                return true;
            });
            return true;
        });
        debugger.addBreakPoint(module.base + 0x25FBC, (emulator2, address) -> {
            // md5Internal
            final RegisterContext context = emulator2.getContext();
            System.out.println("0x25FBC md5Internal");
            UnidbgPointer out = context.getPointerArg(0);
            System.out.println("0x25FBC outPtr: " + out);
            long size = context.getLongArg(2);
            System.out.println("0x25FBC inpLen: " + size);
            byte[] ba = context.getPointerArg(1).getByteArray(0L, (int) Math.min(size, 32L));
            Inspector.inspect(ba, "0x25FBC inp");
            final byte[] preComputed = getMd5(ba);
            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
                System.out.println("0x25FBC retval: " + context.getLongArg(0));
                byte[] nBa = out.getByteArray(0L, 16);
                Inspector.inspect(nBa, "0x25FBC out dump ret");
                System.out.println("isMd5: " + Arrays.equals(nBa, preComputed));
                return true;
            });
            return true;
        });
        debugger.addBreakPoint(module.base + 0x2A5C8, (emulator2, address) -> {
            final RegisterContext context = emulator2.getContext();
            System.out.println("0x2A5C8 initNum");
            final UnidbgPointer a0 = context.getPointerArg(0);
            final UnidbgPointer a1 = context.getPointerArg(1);
            final long a2 = context.getLongArg(2);
            System.out.println("dst " + a0);
            System.out.println("size " + a2);
            Inspector.inspect(a1.getByteArray(0, (int)a2), "data");
            return true;
        });
//        debugger.addBreakPoint(module.base + 0x37654, (emulator2, address) -> {
//            final RegisterContext context = emulator2.getContext();
//            System.out.println("0x37654 modExp");
//            final UnidbgPointer a0 = context.getPointerArg(0);
//            final UnidbgPointer a1 = context.getPointerArg(1);
//            final UnidbgPointer a2 = context.getPointerArg(2);
//            final UnidbgPointer a3 = context.getPointerArg(3);
//            final long a4 = context.getLongArg(4);
//            System.out.println(a0);
//            System.out.println(a1);
//            System.out.println(a2);
//            System.out.println(a3);
//            System.out.println(a4);
//            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
//                System.out.println("0x37654 ret");
//                final UnidbgPointer ret = context.getPointerArg(0);
//                System.out.println(ret);
//                return true;
//            });
//            return true;
//        });
//        debugger.addBreakPoint(module.base + 0x30F4C, (emulator2, address) -> {
//            final RegisterContext context = emulator2.getContext();
//            System.out.println("0x30F4C big mul");
//            final UnidbgPointer a0 = context.getPointerArg(0);
//            final UnidbgPointer a1 = context.getPointerArg(1);
//            final UnidbgPointer a2 = context.getPointerArg(2);
//            System.out.println(a0);
//            System.out.println(a1);
//            System.out.println(a2);
//            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
//                System.out.println("0x30F4C ret");
//                final UnidbgPointer ret = context.getPointerArg(0);
//                System.out.println(ret);
//                return true;
//            });
//            return true;
//        });
//        debugger.addBreakPoint(module.base + 0x36F00, (emulator2, address) -> {
//            final RegisterContext context = emulator2.getContext();
//            System.out.println("0x36F00 big mod");
//            final UnidbgPointer a0 = context.getPointerArg(0);
//            final UnidbgPointer a1 = context.getPointerArg(1);
//            final UnidbgPointer a2 = context.getPointerArg(2);
//            System.out.println(a0);
//            System.out.println(a1);
//            System.out.println(a2);
//            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
//                System.out.println("0x36F00 ret");
//                final UnidbgPointer ret = context.getPointerArg(0);
//                System.out.println(ret);
//                return true;
//            });
//            return true;
//        });
        debugger.addBreakPoint(module.base + 0x2AFE8, (emulator2, address) -> {
            final RegisterContext context = emulator2.getContext();
            System.out.println("0x2AFE8 dump big num");
            final UnidbgPointer a0 = context.getPointerArg(0);
            final UnidbgPointer a1 = context.getPointerArg(1);
            final long a2 = context.getLongArg(2);
            System.out.println(a0);
            System.out.println(a1);
            System.out.println(a2);
            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
                System.out.println("0x2AFE8 ret");
                final UnidbgPointer ret = context.getPointerArg(0);
                System.out.println(ret);
                Inspector.inspect(a1.getByteArray(0, (int) a2), "ret data");
                byte[] wanted = new byte[128];
                wanted[0] = 0;
                wanted[1] = 2;
                Random rnd = new Random();
                byte[] tmp = new byte[1];
                for (int i = 2; i < 2+8; i++) {
                    do {
                        rnd.nextBytes(tmp);
                    } while (tmp[0] == 0);
                    wanted[i] = tmp[0];
                }
                wanted[2+8] = 0;
                try {
                    System.arraycopy(Hex.decodeHex("146c198a47c61725dda9d7f2013808e6"), 0, wanted, 2+8+1, 16);
                } catch (DecoderException e) {
                    throw new RuntimeException(e);
                }
//                for (int i = 2; i < 127; i++) {
//                    wanted[i] = 21;
//                }
                wanted[127] = 0;
//                a1.write(wanted);
                return true;
            });
            return true;
        });
//        debugger.addBreakPoint(module.findSymbolByName("sprintf").getAddress(), (emulator2, address) -> {
//            final RegisterContext context = emulator2.getContext();
//            final Pointer buffer = context.getPointerArg(0);
//
//            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
//                String result = buffer.getString(0);
//                System.out.println("sprintf: " + result);
//                return true;
//            });
//            return true;
//        });
        debugger.addBreakPoint(module.base + 0x21020, (emulator2, address) -> {
            // strcmp for running
            final RegisterContext context = emulator2.getContext();
            System.out.println("mem cmp");
            System.out.println("0x21020 const: " + context.getLongArg(0));
            final int size = context.getIntArg(3);
            System.out.println("0x21020 size: " + context.getLongArg(3));
            Inspector.inspect(context.getPointerArg(1).getByteArray(0L, size), "0x21020 v1");
            Inspector.inspect(context.getPointerArg(2).getByteArray(0L, size), "0x21020 v2");
            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
                // adb running or not cmp size == 7
                // ans cmp == 16
                if (size == 16) {
                    // fake to ok, which lead to return true
//                    emulator1.getBackend().reg_write(Arm64Const.UC_ARM64_REG_X0, 0);
                }
                return true;
            });
            return true;
        });
        long[] decodedFunc = new long[]{0x19398, 0x19C88, 0x18A1C, 0x1A314, 0x23BF4};
        /*
        18a1c(decoded string): /proc/self/maps
        19398(decoded string): %*x-%*lx %*4s %*lx %*s %*s %s
        19c88(decoded string): com.wuaipojie.crackme2024
        1a314(decoded string): /base.apk
        23bf4(decoded string): ([BLjava/lang/String;)Z

         */
        for (long addr : decodedFunc) {
            debugger.addBreakPoint(module.base + addr, (emulator2, address) -> {
                debugger.addBreakPoint(emulator2.getContext().getLRPointer().peer, (emulator1, address1) -> {
                    System.out.println(Long.toHexString(addr) + "(decoded string): " + emulator1.getContext().getPointerArg(0).getString(0));
                    return true;
                });
                return true;
            });
        }
//        debugger.addBreakPoint(module.base + 0x23D8C, (emulator2, address) -> {
//            // decode property to read
//            final RegisterContext context = emulator2.getContext();
//            final var ptr = context.getPointerArg(0);
//            System.out.println(Long.toHexString(ptr.peer));
//            debugger.addBreakPoint(context.getLRPointer().peer, (emulator1, address1) -> {
//                System.out.println("0x23D8C: " + ptr.getString(0));
//                return true;
//            });
//            return true;
//        });
        String data = Base64.getEncoder().encodeToString("1234567890".repeat(100).substring(1).substring(0, 128).getBytes());
        byte[] cc = new byte[128];
        cc[127] = 1;
        data = Base64.getEncoder().encodeToString(cc);
        data = "cjltsy6TaDWwc1CbY0C5FeVN1Ub3KDjSRRAPmKYFwUsf/gcqSpuHvfnZqSPNq6LIiGfjAP/pYvhcHp1nPyUsJNw1h0l8ICNngSn45x4HJY4Ijo8vlycmmcWI2Adcx4V+Ueig2iRRgMEDwF6ccpzVUh3dWN4wSg0hNWp/otJVCH8=";
        data = Base64.getEncoder().encodeToString(new BigInteger("bfbdcc68db43621b3d16e308b8cbb66ad6715da8e46b76f1731bcfa26107ff3012fc585565b3efe01d83d30198078a34f80bade1fb5d23c6ccff8026e6d187de723bdfd1f263d700ca8c664919a885783c40f0eb2fc6282233c14b9efe8f0f995623cd6095d266d3edba0520a34d99e07b3412afc7bde7f26c9b937252786d87", 16).toByteArray());
        map.clear();
        mutable.reset();
        System.out.println(cNative.callStaticJniMethodBoolean(emulator, "checkSn([BLjava/lang/String;)Z", getMd5("00691872"), data));
        System.out.printf("STAT CNT %d %d\n", map.size(), mutable.opCnt);
        if (false) map.forEach((k, v) -> {
            if (v.isCSel) {
                System.out.println(Long.toHexString(v.ins.getAddress()) + " " + v.ins.getMnemonic() + " " + v.opStr + "; diff: " + ((v.brIns.getAddress() - v.ins.getAddress()) / 4) + "; br " + v.brIns.getOpStr() + "; case[0] = " + (v.cases[0] == null ? "(null)" : Long.toHexString(v.cases[0].jumpTarget)) + "; case[1] = " + (v.cases[1] == null ? "(null)" : Long.toHexString(v.cases[1].jumpTarget)));
            } else if (v.jumpRecord != null) {
                System.out.println("jump records(" + v.jumpRecord.size() + "): " + v.jumpRecord.stream().map(Long::toHexString).collect(Collectors.joining(", ")));
            } else if (v.isBLR) {
                System.out.println(Long.toHexString(v.ins.getAddress()) + " " + v.ins.getMnemonic() + " " + v.opStr + " -> " + Long.toHexString(v.BLRTarget) + ((v.BLRTarget == v.ins.getAddress() + 4) ? " NEAR" : ""));
            }
        });
        System.out.println(hooks.sb.toString());
        System.out.print("[ ");
        class OutputClosure {
            boolean isFirst = true;
        }
        final OutputClosure closure = new OutputClosure();
        map.forEach((k, v) -> {
            if (v.isCSel) {
                if (closure.isFirst) closure.isFirst = false;
                else System.out.print(", ");
                System.out.printf("[0x%s, 0x%s, 0x%s, %s, 0x%s]", Long.toHexString(v.ins.getAddress() - module.base), Long.toHexString(v.cases[0].jumpTarget - module.base), Long.toHexString(v.cases[1].jumpTarget - module.base), (v.opStr.endsWith(", eq")) ? "True" : "False", Long.toHexString(v.brIns.getAddress() - module.base));
            }
        });
        System.out.println(" ]");
        System.out.print("[ ");
        closure.isFirst = true;
        mutable.list.forEach((v) -> {
            if (closure.isFirst) closure.isFirst = false;
            else System.out.print(", ");
            System.out.printf("0x%s", Long.toHexString(v - module.base));
        });
        System.out.println(" ]");
        System.out.print("[ ");
        closure.isFirst = true;
        map.forEach((k, v) -> {
            if (v.isBLR) {
                if (v.BLRTarget == v.ins.getAddress() + 4) return;
                if (v.BLRTarget < module.base || v.BLRTarget > module.base + module.size) return;
                if (closure.isFirst) closure.isFirst = false;
                else System.out.print(", ");
                System.out.printf("[0x%s, 0x%s]", Long.toHexString(v.ins.getAddress() - module.base), Long.toHexString(v.BLRTarget - module.base));
            }
        });
        System.out.println(" ]");
        System.out.print("[ ");
        closure.isFirst = true;
        map.forEach((k, v) -> {
            if (v.isBLR) {
                if (v.BLRTarget == v.ins.getAddress() + 4) return;
                if (!(v.BLRTarget < module.base || v.BLRTarget > module.base + module.size)) return;
                if (closure.isFirst) closure.isFirst = false;
                else System.out.print(", ");
                Module module2 = emulator.getMemory().findModuleByAddress(v.BLRTarget);
                Symbol symbol = module2 == null ? null : module2.findClosestSymbolByAddress(v.BLRTarget, true);
                String moduleName = module2 == null ? "(null)" : module2.name;
                String symbolName = symbol == null ? "(null)" : symbol.getName();
                long symbolAddr = symbol == null ? 0 : symbol.getAddress();
                HookedSymbol hookedSymbol = memory.findHookedSymbol(v.BLRTarget);
                if (hookedSymbol != null) {
                    moduleName = hookedSymbol.getLibrary();
                    symbolName = hookedSymbol.getSymbol();
                    symbolAddr = hookedSymbol.getAddress();
                }
                // JNI func not covered here(since it is not required here)
                System.out.printf("[0x%s, \"%s\", \"%s\", 0x%x]", Long.toHexString(v.ins.getAddress() - module.base), moduleName, symbolName, v.BLRTarget - symbolAddr);
            }
        });
        System.out.println(" ]");
        System.out.print("[ ");
        closure.isFirst = true;
        map.forEach((k, v) -> {
            if (v.isBLR) {
                if (v.BLRTarget != v.ins.getAddress() + 4) return;
                if (closure.isFirst) closure.isFirst = false;
                else System.out.print(", ");
                System.out.printf("0x%s", Long.toHexString(v.ins.getAddress() - module.base));
            }
        });
        System.out.println(" ]");
        Inspector.inspect(UnidbgPointer.pointer(emulator, module.base+0x59cc0).getByteArray(0, 0xc8), "read");
        Inspector.inspect(UnidbgPointer.pointer(emulator, module.base+0x54000).getByteArray(0, 0x110), "read");
        Collections.sort(rml);
        rml.stream().distinct().toList().forEach(v -> System.out.printf("0x%x %x @ 0x%x\n", v.address, v.size, v.pc));
    }
}
