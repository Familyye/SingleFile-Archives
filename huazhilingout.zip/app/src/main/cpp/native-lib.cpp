#include <jni.h>
#include <string>
static __attribute__((always_inline)) void Junk_code_012() {
#ifdef __aarch64__
    int arr[]={0x1,0x14,0x4,0x03,0x1,0x032,0x18};
    register long x7 __asm__("x7") = (long) arr;
    __asm__ __volatile__(
            "mov x8,#0x1\n"
            "mov x10,#0x2\n"
            "ldr w10,[x7,#24]\n"
//            这里的点是关键，代表当前pc
            "adr x9, .\n"
            "mov x7, #03\n"
            "add x9, x9, x10\n"
            "mul x8, x9, x8\n"
            "adr x9,.\n"
            "br x8\n":"=r"(x7):"0"(x7):"memory", "cc"
            );
#endif
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_huazhilingout_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    Junk_code_012();
    std::string hello = "Hello from C++1";
    Junk_code_012();
    std::string hello1 = "Hello from C++2";
    Junk_code_012();
    std::string hello2 = "Hello from C++3";
    Junk_code_012();
    return env->NewStringUTF(hello.c_str());
}



